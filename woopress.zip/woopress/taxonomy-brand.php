<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

woocommerce_get_template( 'archive-product.php' );