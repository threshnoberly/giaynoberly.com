<?php
/**
 * The Template for displaying single portfolio project.
 *
 */
    get_template_part('single');
    return;

?>