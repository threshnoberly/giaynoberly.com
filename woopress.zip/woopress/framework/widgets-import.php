<?php 

return array(
	'ecommerce' => array(
		'footer2' => array(
			'flush' => true,
			'create' => false,
			'widgets' => array(
				'etheme-static-block' => array(
					'block_id' => 15605
				),

			)
		),
		'footer10' => array(
			'flush' => true,
			'create' => false,
			'widgets' => array(
				'text' => array(
					'text' => '<img src="http://8theme.com/demo/royal/wp-content/themes/royal/images/assets/payments.png" alt="" />'
				),
			)

		),
		'footer9' => array(
			'flush' => true,
			'create' => false,
			'widgets' => array(
				'text' => array(
					'text' => '<p style="font-size: 14px; margin: 5px 0;">Created with by <span class="active"><i class="fa fa-heart" style="color: #f15;"></i><a href="http://www.8theme.com">8theme</a></span>. All right reserved</p>'
				),
			)

		),	
	),
);




